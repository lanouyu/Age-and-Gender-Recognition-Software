TOOLS=/opt/software/caffe-master/build/tools
DATA=/home/shengbin/G35/lmdb/00/gender_train_lmdb
OUT=/home/shengbin/G35/mean_image/00

$TOOLS/compute_image_mean.bin $DATA $OUT/mean.binaryproto

