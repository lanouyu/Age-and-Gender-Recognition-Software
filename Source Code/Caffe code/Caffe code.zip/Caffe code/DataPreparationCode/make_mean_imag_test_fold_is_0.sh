TOOLS=/opt/software/caffe-master/build/tools
DATA=/home/shengbin/G35/lmdb/Test_fold_is_0/gender_train_lmdb
OUT=/home/shengbin/G35/mean_image/Test_folder_is_0

$TOOLS/compute_image_mean.bin $DATA $OUT/mean.binaryproto

